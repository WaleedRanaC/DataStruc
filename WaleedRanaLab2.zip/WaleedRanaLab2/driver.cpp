//Waleed Rana
//Lab 2
//2/10/2018
//In this lab we are asking the user for inputs into bag1 and bag2 and doing 3 new methods on them which were added to the arrayBag.cppfile
//BagUnion combines the bags
//BagIntersections gives whats similar
//BagDifference is the difference betweem the two bags.


#include <iostream>
#include <string>
#include "ArrayBag.h"

using namespace std;

string menuChoice()
{
	string choice = "";
	cout<<endl;
	cout<<"Menu: "<<endl;
	cout<<"A) Single Digit Integer"<<endl;
	cout<<"B) Single Digit Char"<<endl;
	cout<<"C) Name Strings"<<endl;
	cout<<endl;
	cin>>choice;
	return choice;
}

template <class T>
void displayBag(ArrayBag<T>& bag)
{
	cout << "The bag contains " << bag.getCurrentSize()
        << " items:" << endl;
   vector<T> bagItems = bag.toVector();
   
   int numberOfEntries = (int) bagItems.size();
   for (int i = 0; i < numberOfEntries; i++)
   {
      cout << bagItems[i] << " ";
   }  // end for
	cout << endl << endl;
}  // end displayBag

template <class T>
void bagInput(ArrayBag<T>& bag)
{
   //displayBag(bag);
   
   //Getting number of inputs:
   int numberInputs;
   cout<<"How many items would you like to input?"<<endl;
   cin>>numberInputs;
   T items[numberInputs];
	for (int i = 0; i < numberInputs; i++)
   {
   		T pInput;
   		cout<<"Input "<<i+1<<":"<<endl;
		cin>>items[i];
		bag.add(items[i]);
	}  // end for
   
   displayBag(bag);
   cout<<endl;
   //displayBag(bag);
}  // end bagTester

int main()
{
	//keep going while loop
	string keepGoing = "yes";
	while(keepGoing == "yes")
	{
			
		string choice = menuChoice();
		string killChoice;//this cariable is used so we can choose to either keep going or just stop
		
		if(choice == "A" || choice == "a")
		{
			cout<<"Please Input Single Digit Integer"<<endl;
			//bag 1
			cout<<"Bag 1 input"<<endl;
			ArrayBag<char> bag1;
			bagInput(bag1); //get inputs for bag 1
			cout<<endl;
			
			//bag 2
			cout<<"Bag 2 Input"<<endl;
			ArrayBag<char> bag2;
			bagInput(bag2); //get inputs for bag 2
	
			//result bag
			ArrayBag<char> resultBag;
			
			//bagUnion
			cout<<endl;
			cout<<"Bag Union Test:"<<endl;
			cout<<"---------------"<<endl;
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Union contains:"<<endl;
			resultBag = bag1.bagUnion(bag2);
			displayBag(resultBag);
			
			//Clear the result bag
			resultBag.clear();
	
			//bagIntersection
			cout<<endl;
			cout<<"Bag Intersection Test:"<<endl;
			cout<<"----------------------"<<endl;
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Intersection contains:"<<endl;
			resultBag = bag1.bagIntersection(bag2);
			displayBag(resultBag);
			
			//Clear the result bag
			resultBag.clear();
			
			//bagDifference
			cout<<"Bad Difference Test:"<<endl;
			cout<<"--------------------"<<endl;
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Difference contains:"<<endl;
			resultBag = bag1.bagDifference(bag2);
			displayBag(resultBag);
			
	   		cout << "Inputs Completed!" << endl;
	   		
	   		//Clear the bags
			resultBag.clear();
			bag1.clear();
			bag2.clear();
	   		
	   		//Do it again
	   		cout<<"Would you like to continue? (Y/N): "<<endl;
	   		cin>>killChoice;
	   		if(killChoice == "Y" || killChoice == "y")
	   		{
	   			cout<<endl;
			}
			else if(killChoice == "N" || killChoice == "N")
			{
				cout<<endl;
				cout<<"Ok thanks thats all for now!"<<endl;
				keepGoing = "no";
			}
			else
			{
				cout<<endl;
				cout<<"invalid input sorry"<<endl;
				keepGoing = "no";
			}
			
		}
		else if(choice == "B" || choice == "b")
		{
			cout<<"Please Input Single Digit Char"<<endl;
			//bag 1
			cout<<"Bag 1 input"<<endl;
			ArrayBag<char> bag1;
			bagInput(bag1); //get inputs for bag 1
			cout<<endl;
			
			//bag 2
			cout<<"Bag 2 Input"<<endl;
			ArrayBag<char> bag2;
			bagInput(bag2); //get inputs for bag 2
	
			//result bag
			ArrayBag<char> resultBag;
			
			//bagUnion
			cout<<endl;
			cout<<"Bag Union Test:"<<endl;
			cout<<"---------------"<<endl;
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Union contains:"<<endl;
			resultBag = bag1.bagUnion(bag2);
			displayBag(resultBag);
			
			//Clear the result bag
			resultBag.clear();
	
			//bagIntersection
			cout<<endl;
			cout<<"Bag Intersection Test:"<<endl;
			cout<<"----------------------"<<endl;
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Intersection contains:"<<endl;
			resultBag = bag1.bagIntersection(bag2);
			displayBag(resultBag);
			
			//Clear the result bag
			resultBag.clear();
			
			//bagDifference
			cout<<"Bad Difference Test:"<<endl;
			cout<<"--------------------"<<endl;
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Difference contains:"<<endl;
			resultBag = bag1.bagDifference(bag2);
			displayBag(resultBag);
			
	   		cout << "Inputs Completed!" << endl;
	   		
	   		//Clear the bags
			resultBag.clear();
			bag1.clear();
			bag2.clear();
	   		
	   		//Do it again
	   		cout<<"Would you like to continue? (Y/N): "<<endl;
	   		cin>>killChoice;
	   		if(killChoice == "Y" || killChoice == "y")
	   		{
	   			cout<<endl;
			}
			else if(killChoice == "N" || killChoice == "N")
			{
				cout<<endl;
				cout<<"Ok thanks thats all for now!"<<endl;
				keepGoing = "no";
			}
			else
			{
				cout<<endl;
				cout<<"invalid input sorry"<<endl;
				keepGoing = "no";
			}
			
		}
		else if(choice == "C" || choice == "c")
		{
			cout<<"Please Input Strings: "<<endl;
	
			//bag 1
			cout<<"Bag 1 input"<<endl;
			ArrayBag<string> bag1;
			bagInput(bag1); //get inputs for bag 1
			cout<<endl;
			
			//bag 2
			cout<<"Bag 2 Input"<<endl;
			ArrayBag<string> bag2;
			bagInput(bag2); //get inputs for bag 2
			
			//result bag
			ArrayBag<string> resultBag;
			
			//bagUnion
			cout<<endl;
			cout<<"Bag Union Test:"<<endl;
			cout<<"---------------"<<endl;
			
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Union contains:"<<endl;
			resultBag = bag1.bagUnion(bag2);
			displayBag(resultBag);
			
			//Clear the result bag
			resultBag.clear();
	
			//bagIntersection
			cout<<endl;
			cout<<"Bag Intersection Test:"<<endl;
			cout<<"----------------------"<<endl;
			
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			cout<<"Bag Intersection contains:"<<endl;
			resultBag = bag1.bagIntersection(bag2);
			displayBag(resultBag);
			
			//Clear the result bag
			resultBag.clear();
			
			//bagDifference
			cout<<"Bad Difference Test:"<<endl;
			cout<<"--------------------"<<endl;
			
			cout<<"Bag 1 Contains:"<<endl;
			displayBag(bag1);
			cout<<"Bag 2 Contains:"<<endl;
			displayBag(bag2);
			resultBag = bag1.bagDifference(bag2);
			cout<<"Bag Difference contains:"<<endl;
			displayBag(resultBag);
			
	   		cout << "Inputs Completed!" << endl;
	   		
			//Clear the bags
			resultBag.clear();
			bag1.clear();
			bag2.clear();
			
	   		
	   		//Do it again
	   		cout<<"Would you like to continue? (Y/N): "<<endl;
	   		cin>>killChoice;
	   		if(killChoice == "Y" || killChoice == "y")
	   		{
	   			cout<<endl;
			}
			else if(killChoice == "N" || killChoice == "N")
			{
				cout<<endl;
				cout<<"Ok thanks thats all for now!"<<endl;
				keepGoing = "no";
			}
			else
			{
				cout<<endl;
				cout<<"invalid input sorry"<<endl;
				keepGoing = "no";
			}
		}
		else
		{
		 cout<<"Invalid Input"<<endl;
		}

	}
	
   
   return 0;
}  // end main
